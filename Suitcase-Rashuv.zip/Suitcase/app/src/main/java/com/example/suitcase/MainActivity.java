package com.example.suitcase;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private static final int ADD_ITEM_REQUEST = 50; // Unique request code
    private static final int SHAKE_THRESHOLD = 500; // Adjust this threshold as needed

    private RecyclerView recyclerView;
    private ItemAdapter itemAdapter;
    private List<Item> itemList;
    private FirebaseFirestore firestore;
    private Button logoutButton;
    private FirebaseAuth mAuth;
    private FirebaseUser user;

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private long lastShakeTime;
    private float lastX, lastY, lastZ;

    @Override
    protected void onStart() {
        super.onStart();
        user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            startActivity(new Intent(this, Login.class));
            finish();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();

        // Initialize Firestore and RecyclerView
        firestore = FirebaseFirestore.getInstance();
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Hide the action bar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setTitle("Dashboard");
        }

        // Initialize itemList and adapter
        itemList = new ArrayList<>();
        itemAdapter = new ItemAdapter(this, itemList); // Pass context here
        recyclerView.setAdapter(itemAdapter);

        // Set up swipe-to-delete functionality
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                deleteItem(position);
            }
        });
        itemTouchHelper.attachToRecyclerView(recyclerView);

        FloatingActionButton floatingActionButton = findViewById(R.id.floatingActionButton);
        floatingActionButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, AddItemActivity.class);
            startActivityForResult(intent, ADD_ITEM_REQUEST); // Launch AddItemActivity using startActivityForResult
            Log.d("MainActivity", "Launching AddItemActivity");
        });

        logoutButton = findViewById(R.id.logout);
        logoutButton.setOnClickListener(v -> showLogoutConfirmationDialog());

        fetchItems();

        // Initialize sensor manager and accelerometer
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            long currentTime = System.currentTimeMillis();
            if ((currentTime - lastShakeTime) > 100) {
                long diffTime = currentTime - lastShakeTime;
                lastShakeTime = currentTime;

                float x = event.values[0];
                float y = event.values[1];
                float z = event.values[2];

                float shake = Math.abs(x + y + z - lastX - lastY - lastZ) / diffTime * 10000;
                if (shake > SHAKE_THRESHOLD) {
                    showLogoutConfirmationDialog();
                }

                lastX = x;
                lastY = y;
                lastZ = z;
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not used
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_ITEM_REQUEST && resultCode == RESULT_OK && data != null) {
            // Extract item data from Intent extras
            String itemName = data.getStringExtra("itemName");
            String itemLocation = data.getStringExtra("itemLocation");
            String itemDescription = data.getStringExtra("itemDescription");
            String imageUrl = data.getStringExtra("imageUrl");

            Log.d("MainActivity", "Received Item: " + itemName + ", " + itemLocation + ", " + itemDescription + ", " + imageUrl);

            Item newItem = new Item(itemName, itemLocation, itemDescription, imageUrl);
            itemList.add(newItem);

            // Notify the adapter that a new item has been inserted
            itemAdapter.notifyItemInserted(itemList.size() - 1);
        } else {
            Log.d("MainActivity", "onActivityResult: Request Code or Result Code mismatch or data is null");
        }
    }

    private void fetchItems() {
        firestore.collection("items")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        itemList.clear();
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            Item item = document.toObject(Item.class);
                            item.setId(document.getId());  // Set the document ID to the item
                            itemList.add(item);
                        }
                        itemAdapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(MainActivity.this, "Failed to fetch items: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void deleteItem(int position) {
        Item item = itemList.get(position);
        firestore.collection("items").document(item.getId())
                .delete()
                .addOnSuccessListener(aVoid -> {
                    itemList.remove(position);
                    itemAdapter.notifyItemRemoved(position);
                    Toast.makeText(MainActivity.this, "Item deleted", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> Toast.makeText(MainActivity.this, "Failed to delete item: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void showLogoutConfirmationDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Logout Confirmation")
                .setMessage("Are you sure you want to logout?")
                .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                .setPositiveButton("Yes", (dialog, which) -> {
                    FirebaseAuth.getInstance().signOut();
                    startActivity(new Intent(MainActivity.this, Login.class));
                    finish();
                })
                .show();
    }
}
