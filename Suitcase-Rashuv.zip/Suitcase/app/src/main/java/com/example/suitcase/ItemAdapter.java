package com.example.suitcase;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.textfield.TextInputEditText;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {
    private final List<Item> itemList;
    private final Context context;

    public ItemAdapter(Context context, List<Item> itemList) {
        this.context = context;
        this.itemList = itemList;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_layout, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        Item item = itemList.get(position);
        holder.nameTextView.setText(item.getName());
        holder.locationTextView.setText(item.getLocation());
        holder.descriptionTextView.setText(item.getDescription());
        Glide.with(context).load(item.getImageUrl()).into(holder.img);

        holder.itemView.setOnLongClickListener(v -> {
            showUpdateShareDialog(item);
            return true;
        });

        holder.itemView.setOnClickListener(v -> {
            if (holder.doneImageView.getVisibility() == View.GONE) {
                holder.doneImageView.setVisibility(View.VISIBLE);
                holder.doneImageView.setColorFilter(Color.parseColor("#00FF00")); // Set green color
                Toast.makeText(context, "Marked as purchased", Toast.LENGTH_SHORT).show();
            } else {
                holder.doneImageView.setVisibility(View.GONE);
                Toast.makeText(context, "Unmarked", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView;
        TextView locationTextView;
        TextView descriptionTextView;
        ImageView doneImageView, img;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.itemNameTextView);
            locationTextView = itemView.findViewById(R.id.itemLocationTextView);
            descriptionTextView = itemView.findViewById(R.id.itemDescriptionTextView);
            doneImageView = itemView.findViewById(R.id.doneImageView);
            img = itemView.findViewById(R.id.img);
        }
    }

    private void showUpdateShareDialog(Item item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_update_share, null);
        builder.setView(dialogView);

        TextInputEditText nameEditText = dialogView.findViewById(R.id.editTextName);
        TextInputEditText locationEditText = dialogView.findViewById(R.id.editTextLocation);
        TextInputEditText descriptionEditText = dialogView.findViewById(R.id.editTextDescription);

        nameEditText.setText(item.getName());
        locationEditText.setText(item.getLocation());
        descriptionEditText.setText(item.getDescription());

        builder.setPositiveButton("Update", (dialog, which) -> {
            String updatedName = nameEditText.getText().toString().trim();
            String updatedLocation = locationEditText.getText().toString().trim();
            String updatedDescription = descriptionEditText.getText().toString().trim();

            item.setName(updatedName);
            item.setLocation(updatedLocation);
            item.setDescription(updatedDescription);

            notifyDataSetChanged();
            Toast.makeText(context, "Item updated", Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());

        builder.setNeutralButton("Share", (dialog, which) -> {
            String shareMessage = "Item: " + item.getName() + "\nLocation: " + item.getLocation() + "\nDescription: " + item.getDescription();

            String imageUrl = item.getImageUrl();
            if (imageUrl != null && !imageUrl.isEmpty()) {
                shareMessage += "\nImage: " + imageUrl; // Append image URL to the message
            }

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);

            context.startActivity(Intent.createChooser(shareIntent, "Share Item"));
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
