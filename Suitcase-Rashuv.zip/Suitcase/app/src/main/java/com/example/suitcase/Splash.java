package com.example.suitcase;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Splash extends AppCompatActivity {

    private static final long SPLASH_DELAY_MS = 2000; // 2 seconds delay
    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.activity_splash);

            // Show progress bar
            findViewById(R.id.progressBar).setVisibility(View.VISIBLE);

            // Delayed intent to navigate to Home activity
            handler = new Handler(getMainLooper()); // Use main looper for handler
            handler.postDelayed(() -> {
                startActivity(new Intent(Splash.this, Home.class));
                finish(); // Finish splash activity
            }, SPLASH_DELAY_MS);

        } catch (Exception e) {
            Log.e("SplashActivity", "Error in onCreate:", e); // Log any exceptions
            // Consider displaying an error message to the user or taking other actions
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Remove any pending delayed callbacks to prevent leaks
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
    }
}