package com.example.suitcase;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log; // Import for logging
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.HashMap;
import java.util.Map;

public class AddItemActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1; // Unique request code

    private EditText itemNameEditText;private EditText itemLocationEditText;
    private EditText itemDescriptionEditText;
    private Button saveButton;
    private ImageView imageView;
    private Uri imageUri;

    private FirebaseFirestore firestore;
    private FirebaseStorage storage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_add);

        // Initialize Firestore and Firebase Storage
        firestore = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();

        // Initialize UI elements
        itemNameEditText = findViewById(R.id.itemNameEditText);
        itemLocationEditText = findViewById(R.id.itemLocationEditText);
        itemDescriptionEditText = findViewById(R.id.itemDescriptionEditText);
        saveButton = findViewById(R.id.saveButton);
        imageView = findViewById(R.id.imageView);

        // Set click listener for the ImageView to choose an image
        imageView.setOnClickListener(view -> openFileChooser());

        // Set click listener for the save button
        saveButton.setOnClickListener(view -> saveItem());

        // Make the save button pink (Compatible with all API levels)
        saveButton.setBackgroundColor(getResources().getColor(R.color.black));
    }

    private void openFileChooser() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            // Set the image to fill the ImageView using scaleType
            imageView.setImageURI(imageUri);
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        }
    }

    private void saveItem() {
        String itemName = itemNameEditText.getText().toString();
        String itemLocation = itemLocationEditText.getText().toString();
        String itemDescription = itemDescriptionEditText.getText().toString();

        // Validation logic for empty fields (replace with your actual validation)
        if (itemName.isEmpty() || itemLocation.isEmpty() || itemDescription.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return; // Stop saving if any field is empty
        }

        if (imageUri != null) {
            StorageReference storageRef = storage.getReference().child("item_images/" + System.currentTimeMillis());
            storageRef.putFile(imageUri)
                    .addOnSuccessListener(taskSnapshot -> {
                        storageRef.getDownloadUrl().addOnSuccessListener(uri -> {
                            // Save item to Firestore with image URL
                            Map<String, Object> item = new HashMap<>();
                            item.put("name", itemName);
                            item.put("location", itemLocation);
                            item.put("description", itemDescription);
                            item.put("imageUrl", uri.toString());

                            firestore.collection("items")
                                    .add(item)
                                    .addOnSuccessListener(documentReference -> {
                                        Toast.makeText(AddItemActivity.this, "Item saved!", Toast.LENGTH_SHORT).show();

                                        // Log item data before setting result
                                        Log.d("AddItemActivity", "Sending Result: " + itemName + ", " + itemLocation + ", " + itemDescription + ", " + uri.toString());

                                        // Send result back to MainActivity
                                        Intent resultIntent = new Intent();
                                        resultIntent.putExtra("itemName", itemName);
                                        resultIntent.putExtra("itemLocation", itemLocation);
                                        resultIntent.putExtra("itemDescription", itemDescription);
                                        resultIntent.putExtra("imageUrl", uri.toString());
                                        setResult(RESULT_OK, resultIntent);

                                        // Log before finishing activity
                                        Log.d("AddItemActivity", "Finishing Activity");

                                        finish(); // Close AddItemActivity
                                    })
                                    .addOnFailureListener(e -> {
                                        Toast.makeText(AddItemActivity.this, "Error saving item: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                        // Handle the error appropriately
                                    });
                        });
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(AddItemActivity.this, "Error uploading image: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        // Handle the error appropriately
                    });
        } else {
            // Handle case where no image is selected

            // Save item to Firestore without image URL
            Map<String, Object> item = new HashMap<>();
            item.put("name", itemName);
            item.put("location", itemLocation);
            item.put("description", itemDescription);
            // ... (Add other item data as needed) ...

            firestore.collection("items")
                    .add(item)
                    .addOnSuccessListener(documentReference -> {

                        // Log item data before setting result (no image URL in this case)
                        Log.d("AddItemActivity", "Sending Result: " + itemName + ", " + itemLocation + ", " + itemDescription);

                        // Send result back to MainActivity (even without image)
                        Intent resultIntent = new Intent();
                        resultIntent.putExtra("itemName", itemName);
                        resultIntent.putExtra("itemLocation", itemLocation);
                        resultIntent.putExtra("itemDescription", itemDescription);
                        setResult(RESULT_OK, resultIntent);

                        Toast.makeText(this, "Item Added Successfully", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(this, MainActivity.class));
                        finish(); // Close AddItemActivity
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(AddItemActivity.this, "Error saving item: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        // Handle the error appropriately
                    });
        } // Closing curly brace for the if block
    }
}